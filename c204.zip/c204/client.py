
import socket
from tkinter import *
from  threading import Thread
from PIL import ImageTk, Image
import random

screen_width = None
screen_height = None

SERVER = None
PORT = None
IP_ADDRESS = None


canvas1 = None
canvas2 = None

playerName = None
nameEntry = None
nameWindow = None
gameWindow = None

leftBoxes = []
rightBoxes = []
finishingBox = None

dice = None
rollButton = None

playerType = None
playerTurn = True


def leftBoard():
    global gameWindow
    global leftBoxes
    global screen_height

    xPos = 30
    for box in range(0,11):
        if(box == 0):
            boxLabel = Label(gameWindow, font="onyx 16", width=2, height=1, relief="ridge", borderwidth=0, bg="#FA2600")
            boxLabel.place(x=xPos+50, y=screen_height/2 - 160)
            leftBoxes.append(boxLabel)
            xPos += 50
        else:
            boxLabel = Label(gameWindow, font="onyx 16", width=2, height=1, relief="ridge", borderwidth=0, bg="#C72100")
            boxLabel.place(x=xPos+50, y=screen_height/2 - 160)
            leftBoxes.append(boxLabel)
            xPos += 75


def rightBoard():
    global gameWindow
    global rightBoxes
    global screen_height

    xPos = 980
    for box in range(0,11):
        if(box == 10):
            boxLabel = Label(gameWindow, font="onyx 16", width=2, height=1, relief="ridge", borderwidth=0, bg="#00BA28")
            boxLabel.place(x=xPos+50, y=screen_height/2 - 160)
            rightBoxes.append(boxLabel)
            xPos += 50
        else:
            boxLabel = Label(gameWindow, font="onyx 16", width=2, height=1, relief="ridge", borderwidth=0, bg="#009929")
            boxLabel.place(x=xPos+50, y=screen_height/2 - 160)
            rightBoxes.append(boxLabel)
            xPos += 75


def finishBox():
    global gameWindow
    global finishingBox
    global screen_height
    global screen_width

    finishingBox = Label(gameWindow, text="HOME", font="onyx 16 bold", width=8, height=4, relief="ridge", borderwidth=0, bg="#ADADAD", fg="#9C9C9C")
    finishingBox.place(x=screen_width/2 - 75, y=screen_height/2-160)

def rollDice():
    global SERVER
    diceChoices = ['\u2680','\u2681','\u2682','\u2683','\u2684','\u2685']
    value = random.choice(diceChoices)
    global playerType
    global playerTurn
    global rollButton
    rollButton.destroy()
    playerTurn = False

    if(playerType == "player1"):
        SERVER.send(f'{value}player2Turn'.encode())
    if(playerType == "player2"):
        SERVER.send(f'{value}player1Turn'.encode())


def game_window():
    global gameWindow
    global screen_width
    global screen_height
    global canvas2
    global dice

    gameWindow = Tk()
    gameWindow.title("Ludo Ladder")
    gameWindow.attributes("-fullscreen", True)

    screen_width = gameWindow.winfo_screenwidth()
    screen_height = gameWindow.winfo_screenheight()

    bg = ImageTk.PhotoImage(file="./assets/background.png")

    canvas2 = Canvas(gameWindow, width=500, height=500)
    canvas2.pack(fill="both", expand=True)
    canvas2.create_image(0, 0, image=bg, anchor="nw")
    canvas2.create_text(screen_width/2, screen_height/5, text="Ludo Ladder", font="onyx 24 bold", fill="#4D4D4D")
    leftBoard()
    rightBoard()
    finishBox()

    global rollButton
    rollButton = Button(gameWindow, text="Roll!", font="onyx 16 bold", fg="#000000", bg="#ADADAD", width=20, height=5, command=rollDice)
    global playerTurn
    global playerType
    global playerName

    if(playerType == "player1" and playerTurn):
        rollButton.place(x=screen_width/2 - 80, y=screen_height/2 + 250)
    else:
        rollButton.pack_forget()

    dice = canvas2.create_text(screen_width/2 + 10, screen_height/2 + 100, text="\u2680", font="onyx 12")

    gameWindow.resizable(True, True)
    
    gameWindow.mainloop()





def saveName():
    global SERVER
    global playerName
    global nameEntry
    global nameWindow

    playerName = nameEntry.get()
    nameEntry.delete(0,END)
    nameWindow.destroy()
    SERVER.send(playerName.encode())
    game_window()

#Teacher write code here for askPlayerName()
def askPlayerName():
    global playerName
    global nameEntry
    global nameWindow
    global canvas1
    global screen_width
    global screen_height

    nameWindow = Tk()
    nameWindow.title("Ludo Ladder")
    nameWindow.attributes("-fullscreen", True)
    
    screen_height = nameWindow.winfo_screenwidth()
    screen_width = nameWindow.winfo_screenwidth()
    
    bg = ImageTk.PhotoImage(file="./assets/background.png")
    
    canvas1 = Canvas(nameWindow, width=500, height=500)
    canvas1.pack(fill="both", expand=True)
    canvas1.create_image(0, 0, image=bg, anchor="nw")
    canvas1.create_text(screen_width/2, screen_height/5, text="enter name:", font="onyx 14 bold", fill="#2C65F5")
    
    nameEntry = Entry(nameWindow, width=25, font="onyx 14 bold", justify="center", bg="#0DB1FC")
    nameEntry.place(x=(screen_width/2) - 140, y=screen_height/4.5)
    
    button = Button(nameWindow, text="save", font="onyx 12 bold", command=saveName, width=20, height=4, bg="#0DB1FC", bd=3)
    button.place(x=(screen_width/2) - 110, y=screen_height/4)
    
    nameWindow.resizable(True, True)
    nameWindow.mainloop()
    



def setup():
    global SERVER
    global PORT
    global IP_ADDRESS

    PORT  = 5000
    IP_ADDRESS = '127.0.0.1'

    SERVER = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    SERVER.connect((IP_ADDRESS, PORT))
 

    # Creating First Window
    askPlayerName()




setup()
